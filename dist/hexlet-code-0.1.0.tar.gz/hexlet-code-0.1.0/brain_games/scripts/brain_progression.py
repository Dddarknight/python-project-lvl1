from brain_games.games import game


def main():
    print('brain-progression!' + '\n' + 'Welcome to the Brain Games!')
    game('progression')


if __name__ == '__main__':
    main()
