from brain_games.games import game


def main():
    print('brain-gcd!' + '\n' + 'Welcome to the Brain Games!')
    game('gcd')


if __name__ == '__main__':
    main()
