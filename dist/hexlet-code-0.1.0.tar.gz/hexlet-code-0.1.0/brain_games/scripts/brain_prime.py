from brain_games.games import game


def main():
    print('brain-prime!' + '\n' + 'Welcome to the Brain Games!')
    game('prime')


if __name__ == '__main__':
    main()
