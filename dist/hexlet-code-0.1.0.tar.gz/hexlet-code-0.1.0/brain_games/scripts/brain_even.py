from brain_games.even import even


def main():
    print('brain-even!' + '\n' + 'Welcome to the Brain Games!')
    even()


if __name__ == '__main__':
    main()
