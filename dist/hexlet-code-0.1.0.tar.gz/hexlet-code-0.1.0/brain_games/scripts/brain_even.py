from brain_games.games import game


def main():
    print('brain-even!' + '\n' + 'Welcome to the Brain Games!')
    game('even')


if __name__ == '__main__':
    main()
