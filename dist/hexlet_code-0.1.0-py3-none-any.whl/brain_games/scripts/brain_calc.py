from brain_games.games import game


def main():
    print('brain-calc!' + '\n' + 'Welcome to the Brain Games!')
    game('calc')


if __name__ == '__main__':
    main()
